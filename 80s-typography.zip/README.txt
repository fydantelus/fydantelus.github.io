A Pen created at CodePen.io. You can find this one at https://codepen.io/boldfacedesign/pen/EoGgD.

 I've successfully combined 4 things I absolutely love, Typography, Design, Web Development and 80s style bravado.
Super happy with the results. All done in CSS.